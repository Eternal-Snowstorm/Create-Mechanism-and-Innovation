# Cu-Again
A Minecraft Resource pack for mod ”Create”
Bring C0.5 color of copper into C6.0

<img width="32" height="32" alt="pack" src="https://github.com/user-attachments/assets/cabb0167-97f1-4675-8da3-cdb84f2b07dd" />
